

<div class="row">
  <div class="col-md-12">
    <div class="form-group">
        <label for="explanation">
			ספר/י לנו על הפרויקט שלכם...‏‏‏
        </label>
        <textarea v-model="explanation"  class="form-control" id="explanation"></textarea>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="form-group">
        <label for="points_for_improvement">
			ציין מספר נקודות לשיפור‏‏‏
        </label>
        <textarea v-model="points_for_improvement"  class="form-control" id="points_for_improvement"></textarea>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="form-group">
        <label for="points_for_preservation">
			ציין מספר נקודות לשימור‏‏‏
        </label>
        <textarea v-model="points_for_preservation"  class="form-control" id="points_for_preservation"></textarea>
    </div>
  </div>
</div>


<div class="row"  style=" margin-top: 50px; ">
  <div class="col-md-6">
    <div  class="btu-prev">לשלב הקודם</div>
  </div>
  <div class="col-md-6">
    <div  class="btu-next">המשך</div>
  </div>  
</div>
