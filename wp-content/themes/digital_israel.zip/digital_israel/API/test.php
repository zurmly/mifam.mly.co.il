<?php 

+kint::dump($_POST['fields']);
 ?>