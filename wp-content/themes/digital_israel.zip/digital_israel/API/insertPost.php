<?php 
+kint::dump($_POST['fields']);
// $data = array( 'username' => 'mly', 'password' => '!digital-israel$' );
// array_push($data, $_POST['fields']);
// $data = $_POST['fields'];
// $data['username'] = 'mly';
// $data['password'] = '!digital-israel$';
// +kint::dump($data);
// echo $url = 'http://digital-israel.org/wp-json/acf/v3/posts/'.get_the_ID();
// $response = wp_remote_post( $url, array(
// 	'method' => 'POST',
// 	'timeout' => 45,
// 	'redirection' => 5,
// 	'httpversion' => '1.0',
// 	'blocking' => true,
// 	'headers' => array(),
// 	'body' => $data,
// 	'cookies' => array()
//     )
// );

 ?>